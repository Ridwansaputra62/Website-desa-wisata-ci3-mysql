<footer id="footer" class="footer">
  <div class="container">
    <p>&copy; Copyright Desa Wisata</p>
  </div>
</footer>
</body>
</html>