<section id='contact'>
  <div class='container'>
    <h2>Kontak</h2>
  </div>
</section>