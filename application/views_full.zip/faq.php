<section id='faq'>
  <div class='container-fluid'>
    <h2>FAQ</h2>
  </div>
</section>