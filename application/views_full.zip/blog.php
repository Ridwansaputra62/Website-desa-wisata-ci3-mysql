<section id='recent-blog-posts'>
  <div class='container'>
    <h2>Blog</h2>
  </div>
</section>