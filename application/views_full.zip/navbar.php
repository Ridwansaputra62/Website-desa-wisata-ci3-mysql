<header id="header" class="header fixed-top">
  <div class="container-fluid d-flex align-items-center justify-content-between">
    <a href="<?= base_url('home'); ?>" class="logo scrollto me-auto me-lg-0">
      <img src="<?= base_url('assets/images/users/' . $user['image']); ?>" alt="Logo" class="logo-img">
    </a>
    <nav id="navbar" class="navbar">
      <ul>
        <li><a class="nav-link scrollto" href="#">Beranda</a></li>
        <li><a class="nav-link scrollto" href="#about">Tentang</a></li>
        <li><a class="nav-link scrollto" href="#services">Paket Wisata</a></li>
        <li><a class="nav-link scrollto" href="#portfolio">Galeri</a></li>
        <li><a class="nav-link scrollto" href="#team">Video</a></li>
        <li><a href="<?= base_url('artikel'); ?>">Artikel</a></li>
        <li><a class="nav-link scrollto" href="#contact">Kontak</a></li>
      </ul>
      <i class="bi bi-list mobile-nav-toggle"></i>
    </nav>
  </div>
</header>