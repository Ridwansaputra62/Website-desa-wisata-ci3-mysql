<section id='onfocus'>
  <div class='container-fluid'>
    <h2>Fokus Wisata</h2>
  </div>
</section>