<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Desa Wisata</title>
  <link href="<?=base_url('assets/fe/'); ?>img/favicon.png" rel="icon">
  <link href="<?=base_url('assets/fe/'); ?>css/main.css" rel="stylesheet">
</head>
<body>