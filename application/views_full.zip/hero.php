<section id="hero-animated" class="hero-animated d-flex align-items-center">
  <div class="container d-flex flex-column justify-content-center align-items-center text-center">
    <img src="<?=base_url('assets/fe/'); ?>img/hero-carousel/desa-wisata.webp" class="img-fluid animated">
    <h2>Selamat Datang di Website <span>Desa Sedari</span></h2>
    <p>Jelajahi keindahan hutan mangrove dan pantai sedari</p>
    <div class="d-flex">
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
      <a href="https://www.youtube.com/watch?v=Q-2O-cCZKIM" class="glightbox btn-watch-video">
        <i class="bi bi-play-circle"></i><span>Watch Video</span>
      </a>
    </div>
  </div>
</section>