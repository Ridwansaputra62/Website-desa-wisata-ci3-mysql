<section id='features'>
  <div class='container'>
    <h2>Fitur</h2>
  </div>
</section>