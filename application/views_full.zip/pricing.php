<section id='pricing'>
  <div class='container'>
    <h2>Harga</h2>
  </div>
</section>